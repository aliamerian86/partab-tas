import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import {
  IonContent,
  IonHeader,
  IonPage,
  IonTitle,
  IonToolbar,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonInput,
  IonItem,
  IonButton,
  IonModal,
} from '@ionic/react';
import { Table } from 'react-bootstrap';
import './Tab1.css';
import swal from 'sweetalert';

function randInt(min : number, max : number) {
  return Math.floor(Math.random() * (max - min) ) + min;
}

const Tab1: React.FC = () => {

  let onel
  let twol
  let thrl
  let furl
  let fivl
  let sixl

  let one = []
  let two = []
  let thr = []
  let fur = []
  let fiv = []
  let six = []

  const [number, setNumber] = useState<number>();

  const cV = () => {
    if (!number || number == undefined || number == null || number == 0) {
      swal({
        title: "لطفا فرم را كامل كنيد.",
        icon: "error",
	      buttons: ["متوجه شدم", false],
      })
    } else {
      for (let i = 0; i < Number(number); i++) {
        var random = randInt(1,7)
        switch(random) {
          case 1:
            one.push(random)
            break;
          case 2:
            two.push(random)
            break;
          case 3:
            thr.push(random)
            break;
          case 4:
            fur.push(random)
            break;
          case 5:
            fiv.push(random)
            break;
          case 6:
            six.push(random)
            break;
        }
      }
      onel = one.length
      twol = two.length
      thrl = thr.length
      furl = fur.length
      fivl = fiv.length
      sixl = six.length
  
      ReactDOM.render(
        (
          <div>
            <h3 className="text-center mt-2 mb-2">تعداد رو شدن اعداد تاس</h3>
            <Table striped bordered hover size="sm" className='ltr'>
              <thead>
                <tr>
                  <td className="text-center">۱</td>
                  <td className="text-center">۲</td>
                  <td className="text-center">۳</td>
                  <td className="text-center">۴</td>
                  <td className="text-center">۵</td>
                  <td className="text-center">۶</td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="text-center">{onel}</td>
                  <td className="text-center">{twol}</td>
                  <td className="text-center">{thrl}</td>
                  <td className="text-center">{furl}</td>
                  <td className="text-center">{fivl}</td>
                  <td className="text-center">{sixl}</td>
                </tr>
              </tbody>
            </Table>
          </div>
        ),
        document.getElementById('table')
      )
      onel = 0
      twol = 0
      thrl = 0
      furl = 0
      fivl = 0
      sixl = 0
      one = []
      two = []
      thr = []
      fur = []
      fiv = []
      six = []

    }
  }

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>نمایش احتمال تجربی به ریاضی</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="bg">
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">نمایش احتمال تجربی به ریاضی</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonCard>
          <IonCardHeader>
            <IonCardHeader>
              <IonCardSubtitle>تعداد پرتاب تاس را مشخص کنید تا تعداد بارهایی که هر عدد رو شده نمایش داده شوند.</IonCardSubtitle>
            </IonCardHeader>
          </IonCardHeader>
          <IonCardContent>
            <IonItem>
              <IonInput value={number} className="input" placeholder="دور پرتاب تاس" type="number" onIonChange={ e => setNumber(Number(e.detail.value)) }></IonInput>
            </IonItem>
            <IonButton expand="block" onClick={cV}>ثبت</IonButton>
            <div id="table">

            </div>
          </IonCardContent>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Tab1;
